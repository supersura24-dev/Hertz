package com.hz.music

import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableSmoothRefreshRate()
    }

    private fun enableSmoothRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val attrs = window.attributes
                attrs.preferredRefreshRate = 120f
                window.attributes = attrs
            }
        } catch (_: Exception) {
            // The app still runs normally if the device ignores this request.
        }
    }
}
