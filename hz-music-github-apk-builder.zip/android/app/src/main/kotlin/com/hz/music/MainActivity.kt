package com.hz.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.hz.music/local_audio"
    private val audioPermissionRequest = 2408
    private var pendingScanResult: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableHighestRefreshRate()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "scanSongs" -> {
                    pendingScanResult = result
                    scanSongsWithPermission()
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun scanSongsWithPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), audioPermissionRequest)
            return
        }

        pendingScanResult?.success(queryLocalSongs())
        pendingScanResult = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingScanResult?.success(queryLocalSongs())
            } else {
                pendingScanResult?.error("permission_denied", "Audio permission denied", null)
            }
            pendingScanResult = null
        }
    }

    private fun queryLocalSongs(): List<Map<String, Any?>> {
        val songs = mutableListOf<Map<String, Any?>>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > ?"
        val selectionArgs = arrayOf("30000")
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        contentResolver.query(collection, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val contentUri = ContentUris.withAppendedId(collection, id).toString()
                songs.add(
                    mapOf(
                        "id" to id,
                        "title" to (cursor.getString(titleColumn) ?: "Unknown song"),
                        "artist" to (cursor.getString(artistColumn) ?: "Unknown artist"),
                        "album" to (cursor.getString(albumColumn) ?: ""),
                        "duration" to cursor.getLong(durationColumn),
                        "uri" to contentUri
                    )
                )
            }
        }
        return songs
    }

    @Suppress("DEPRECATION")
    private fun enableHighestRefreshRate() {
        try {
            val attrs = window.attributes

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val displayRef = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    windowManager.defaultDisplay
                }

                val bestMode = displayRef?.supportedModes
                    ?.maxByOrNull { it.refreshRate }

                if (bestMode != null) {
                    attrs.preferredDisplayModeId = bestMode.modeId
                    attrs.preferredRefreshRate = bestMode.refreshRate
                } else {
                    attrs.preferredRefreshRate = 120f
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                attrs.preferredRefreshRate = 120f
            }

            window.attributes = attrs
        } catch (_: Exception) {
            // If the device blocks refresh-rate selection, Flutter still runs normally.
        }
    }
}
