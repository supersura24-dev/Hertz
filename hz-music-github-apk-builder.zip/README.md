# Hz Music V2

A Flutter Android prototype for playing local downloaded songs. Tap Import local songs and choose audio files from your phone.

Features:
- Official Hz Music logo
- Local file playback using file picker
- MP3/M4A/AAC/WAV/FLAC/OGG support depends on Android device codecs
- Smooth dark UI with 120Hz refresh-rate request on supported phones
