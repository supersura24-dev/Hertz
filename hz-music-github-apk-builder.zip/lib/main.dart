import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

void main() {
  runApp(const HzMusicApp());
}

class HzMusicApp extends StatelessWidget {
  const HzMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFFFF8A00);
    return MaterialApp(
      title: 'Hz Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0708),
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF1A1113),
        ),
      ),
      home: const MusicHomePage(),
    );
  }
}

class LocalSong {
  const LocalSong({
    required this.title,
    required this.artist,
    required this.path,
    required this.index,
  });

  final String title;
  final String artist;
  final String path;
  final int index;

  String get fileName => path.split(Platform.pathSeparator).last;
}

class MusicHomePage extends StatefulWidget {
  const MusicHomePage({super.key});

  @override
  State<MusicHomePage> createState() => _MusicHomePageState();
}

class _MusicHomePageState extends State<MusicHomePage> {
  final AudioPlayer _player = AudioPlayer();
  final TextEditingController _searchController = TextEditingController();

  List<LocalSong> _songs = [];
  LocalSong? _currentSong;
  String _query = '';
  bool _loading = false;

  @override
  void dispose() {
    _player.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _importSongs() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: true,
        withData: false,
      );

      if (result == null || result.files.isEmpty) return;

      final imported = <LocalSong>[];
      for (final file in result.files) {
        final path = file.path;
        if (path == null || path.trim().isEmpty) continue;
        final rawName = file.name.trim().isEmpty ? path.split(Platform.pathSeparator).last : file.name.trim();
        final title = rawName.replaceAll(RegExp(r'\.(mp3|m4a|aac|wav|flac|ogg)$', caseSensitive: false), '');
        imported.add(
          LocalSong(
            title: title,
            artist: 'Local file',
            path: path,
            index: DateTime.now().microsecondsSinceEpoch + imported.length,
          ),
        );
      }

      if (!mounted) return;
      setState(() {
        _songs = [..._songs, ...imported];
      });

      if (imported.isNotEmpty && _currentSong == null) {
        await _playSong(imported.first);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not import songs: $e')),
      );
    }
  }

  List<LocalSong> get _filteredSongs {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _songs;
    return _songs.where((song) {
      return '${song.title} ${song.artist} ${song.fileName}'.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _playSong(LocalSong song) async {
    try {
      setState(() {
        _loading = true;
        _currentSong = song;
      });
      await _player.setFilePath(song.path);
      await _player.play();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not play ${song.title}. Try another file.')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _togglePlay() async {
    if (_currentSong == null) {
      if (_filteredSongs.isNotEmpty) await _playSong(_filteredSongs.first);
      return;
    }
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> _skip(int direction) async {
    final list = _filteredSongs.isNotEmpty ? _filteredSongs : _songs;
    if (list.isEmpty) return;
    final current = _currentSong;
    final index = current == null ? -1 : list.indexWhere((song) => song.index == current.index);
    final nextIndex = index < 0 ? 0 : (index + direction) % list.length;
    final safeIndex = nextIndex < 0 ? list.length - 1 : nextIndex;
    await _playSong(list[safeIndex]);
  }

  @override
  Widget build(BuildContext context) {
    final visibleSongs = _filteredSongs;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 4),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset('assets/hz_logo.png', width: 58, height: 58, fit: BoxFit.cover),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hz Music', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
                        SizedBox(height: 2),
                        Text('V2 Local Player • 120Hz ready', style: TextStyle(color: Colors.white60)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Import local songs',
                    onPressed: _importSongs,
                    icon: const Icon(Icons.library_add_rounded),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 46,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                scrollDirection: Axis.horizontal,
                children: const [
                  HzChip(label: 'Local files'),
                  HzChip(label: 'Downloads'),
                  HzChip(label: 'MP3'),
                  HzChip(label: 'FLAC/WAV'),
                  HzChip(label: 'Hz Surround soon'),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 10),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF3A1615), Color(0xFF14090B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: const Color(0x44FFB199)),
                  boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 28, offset: Offset(0, 16))],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Your downloaded songs', style: TextStyle(color: Color(0xFFFFC0CB))),
                          const SizedBox(height: 6),
                          Text(
                            _currentSong?.title ?? '${_songs.length} imported songs',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _currentSong?.artist ?? 'Tap + to choose songs from Downloads/Music',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    StreamBuilder<bool>(
                      stream: _player.playingStream,
                      builder: (context, snapshot) {
                        final playing = snapshot.data ?? false;
                        return FilledButton.tonal(
                          onPressed: _loading || _songs.isEmpty ? null : _togglePlay,
                          child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: InputDecoration(
                  hintText: 'Search imported songs...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _query = '');
                          },
                        ),
                  filled: true,
                  fillColor: const Color(0xFF1B1214),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: visibleSongs.isEmpty
                  ? EmptyState(onPressed: _importSongs)
                  : SongList(songs: visibleSongs, currentSong: _currentSong, onSongTap: _playSong),
            ),
          ],
        ),
      ),
      bottomNavigationBar: MiniPlayer(
        player: _player,
        song: _currentSong,
        loading: _loading,
        onPlayPause: _togglePlay,
        onPrevious: () => _skip(-1),
        onNext: () => _skip(1),
      ),
    );
  }
}

class HzChip extends StatelessWidget {
  const HzChip({super.key, required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: BoxDecoration(color: const Color(0xFF211719), borderRadius: BorderRadius.circular(18)),
      child: Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.onPressed});
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.folder_music_rounded, size: 78, color: Color(0xFFFFC0CB)),
            const SizedBox(height: 18),
            const Text('Import your songs', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
            const SizedBox(height: 8),
            const Text(
              'Tap the button below and choose MP3, M4A, WAV, FLAC or OGG files from your phone.',
              style: TextStyle(color: Colors.white60),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: onPressed,
              icon: const Icon(Icons.library_add_rounded),
              label: const Text('Import local songs'),
            ),
          ],
        ),
      ),
    );
  }
}

class SongList extends StatelessWidget {
  const SongList({super.key, required this.songs, required this.currentSong, required this.onSongTap});
  final List<LocalSong> songs;
  final LocalSong? currentSong;
  final ValueChanged<LocalSong> onSongTap;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 118),
      itemCount: songs.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (context, index) {
        final song = songs[index];
        final active = currentSong?.index == song.index;
        return Material(
          color: active ? const Color(0x22FFB199) : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
            leading: SongArtwork(song: song, size: 54),
            title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: active ? FontWeight.w900 : FontWeight.w700)),
            subtitle: Text(song.fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Icon(active ? Icons.graphic_eq_rounded : Icons.play_arrow_rounded, size: 34),
            onTap: () => onSongTap(song),
          ),
        );
      },
    );
  }
}

class SongArtwork extends StatelessWidget {
  const SongArtwork({super.key, required this.song, required this.size});
  final LocalSong song;
  final double size;

  @override
  Widget build(BuildContext context) {
    final initials = song.title.trim().isEmpty ? 'Hz' : song.title.trim()[0].toUpperCase();
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.25),
      child: Container(
        width: size,
        height: size,
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFFFF8A00), Color(0xFF6D2838)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Center(child: Text(initials, style: TextStyle(color: Colors.white, fontSize: size * 0.42, fontWeight: FontWeight.w900))),
      ),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({
    super.key,
    required this.player,
    required this.song,
    required this.loading,
    required this.onPlayPause,
    required this.onPrevious,
    required this.onNext,
  });

  final AudioPlayer player;
  final LocalSong? song;
  final bool loading;
  final VoidCallback onPlayPause;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    final activeSong = song;
    return Container(
      decoration: BoxDecoration(color: const Color(0xFF120D0F).withOpacity(0.98), border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08)))),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              PositionBar(player: player),
              Row(
                children: [
                  activeSong == null
                      ? Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(color: const Color(0xFF26181B), borderRadius: BorderRadius.circular(13)),
                          child: const Icon(Icons.music_note_rounded, size: 32),
                        )
                      : SongArtwork(song: activeSong, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(activeSong?.title ?? 'No song playing', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                        Text(activeSong == null ? 'Import a local song to play' : activeSong.fileName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.skip_previous_rounded), onPressed: onPrevious),
                  StreamBuilder<bool>(
                    stream: player.playingStream,
                    builder: (context, snapshot) {
                      final playing = snapshot.data ?? false;
                      if (loading) {
                        return const SizedBox(width: 48, height: 48, child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2)));
                      }
                      return IconButton(icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, size: 42), onPressed: onPlayPause);
                    },
                  ),
                  IconButton(icon: const Icon(Icons.skip_next_rounded), onPressed: onNext),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PositionBar extends StatelessWidget {
  const PositionBar({super.key, required this.player});
  final AudioPlayer player;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: player.positionStream,
      builder: (context, positionSnapshot) {
        return StreamBuilder<Duration?>(
          stream: player.durationStream,
          builder: (context, durationSnapshot) {
            final position = positionSnapshot.data ?? Duration.zero;
            final duration = durationSnapshot.data ?? Duration.zero;
            final max = math.max(duration.inMilliseconds.toDouble(), 1.0).toDouble();
            final value = math.min(position.inMilliseconds.toDouble(), max).toDouble();
            return SliderTheme(
              data: SliderTheme.of(context).copyWith(trackHeight: 2, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5)),
              child: Slider(
                value: value,
                max: max,
                onChanged: duration == Duration.zero ? null : (newValue) => player.seek(Duration(milliseconds: newValue.round())),
              ),
            );
          },
        );
      },
    );
  }
}
